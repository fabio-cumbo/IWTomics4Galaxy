This tool requires the following dependencies:
1. R (https://cran.r-project.org/)
2. R/Bioconductor package IWTomics (https://bioconductor.org/packages/release/bioc/html/IWTomics.html)
